from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import MetaTrader5 as mt5
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

app = Flask(__name__)
CORS(app)

TIMEFRAME_MAP = {
    "M1":  mt5.TIMEFRAME_M1,
    "M5":  mt5.TIMEFRAME_M5,
    "M15": mt5.TIMEFRAME_M15,
    "M30": mt5.TIMEFRAME_M30,
    "H1":  mt5.TIMEFRAME_H1,
    "H4":  mt5.TIMEFRAME_H4,
    "D1":  mt5.TIMEFRAME_D1,
}

DAYS_PT = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]

def init_mt5():
    if not mt5.initialize():
        return False, mt5.last_error()
    return True, None

def shutdown_mt5():
    mt5.shutdown()

# ── INDICADORES TÉCNICOS ──────────────────────────────────────────────────────

def calc_rsi(series, period=14):
    delta = series.diff()
    gain  = delta.clip(lower=0)
    loss  = -delta.clip(upper=0)
    avg_gain = gain.ewm(com=period - 1, min_periods=period).mean()
    avg_loss = loss.ewm(com=period - 1, min_periods=period).mean()
    rs  = avg_gain / avg_loss.replace(0, np.nan)
    rsi = 100 - (100 / (1 + rs))
    return rsi.fillna(50)

def calc_ema(series, period):
    return series.ewm(span=period, adjust=False).mean()

def calc_bollinger(series, period=20, std_dev=2):
    sma   = series.rolling(period).mean()
    std   = series.rolling(period).std()
    upper = sma + std_dev * std
    lower = sma - std_dev * std
    # Posição relativa: 0 = na banda inferior, 1 = na superior
    boll_pos = ((series - lower) / (upper - lower).replace(0, np.nan)).fillna(0.5)
    return boll_pos.clip(0, 1)

def calc_volume_ratio(volume_series, period=20):
    avg_vol = volume_series.rolling(period).mean()
    return (volume_series / avg_vol.replace(0, np.nan)).fillna(1.0)

def enrich_dataframe(df):
    """Adiciona indicadores técnicos ao DataFrame de candles."""
    df = df.copy()
    df["rsi"]        = calc_rsi(df["close"], 14)
    df["ema9"]       = calc_ema(df["close"], 9)
    df["ema21"]      = calc_ema(df["close"], 21)
    df["ema50"]      = calc_ema(df["close"], 50)
    df["boll_pos"]   = calc_bollinger(df["close"], 20)
    df["vol_ratio"]  = calc_volume_ratio(df["tick_volume"], 20)
    df["direction"]  = df.apply(lambda r: "CALL" if r["close"] > r["open"] else "PUT", axis=1)
    df["hhmm"]       = df["time"].dt.strftime("%H:%M")
    df["weekday"]    = df["time"].dt.weekday   # 0=seg … 6=dom
    df["hour_only"]  = df["time"].dt.hour
    return df

def composite_score(row, direction):
    """
    Score composto 0–100 que combina 4 fatores:
      - Acerto histórico naquele horário       40%
      - RSI favorável à direção               25%
      - EMA alinhada com a direção            20%
      - Volume acima da média                 15%
    """
    hist_score  = row.get("hist_score", 50)          # 0–100

    rsi         = row.get("rsi_avg", 50)
    if direction == "CALL":
        rsi_score = max(0, min(100, (50 - rsi) * -2 + 50))   # RSI baixo → CALL favorável (sobrevenda)
        rsi_score = 100 - rsi_score if rsi > 50 else rsi_score + (50 - rsi)
        rsi_score = max(0, min(100, (70 - rsi) / 20 * 100))  # RSI < 70 favorece CALL
    else:
        rsi_score = max(0, min(100, (rsi - 30) / 20 * 100))  # RSI > 30 favorece PUT

    ema_aligned = row.get("ema_aligned", 0.5)        # 0 ou 1
    ema_score   = ema_aligned * 100

    vol_ratio   = row.get("vol_ratio_avg", 1.0)
    vol_score   = min(100, vol_ratio * 50)            # Vol 2x média = 100pts

    final = (
        hist_score  * 0.40 +
        rsi_score   * 0.25 +
        ema_score   * 0.20 +
        vol_score   * 0.15
    )
    return round(final, 1)

# ── ROTAS ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/symbols", methods=["GET"])
def get_symbols():
    ok, err = init_mt5()
    if not ok:
        return jsonify({"error": f"MT5 init failed: {err}"}), 500
    symbols = mt5.symbols_get()
    shutdown_mt5()
    if symbols is None:
        return jsonify({"error": "No symbols found"}), 500
    names = sorted([s.name for s in symbols])
    return jsonify({"symbols": names})

@app.route("/api/analyze", methods=["POST"])
def analyze():
    data   = request.json
    symbol = data.get("symbol", "EURUSD")
    tf_str = data.get("timeframe", "M5")
    days   = int(data.get("days", 10))

    ok, err = init_mt5()
    if not ok:
        return jsonify({"error": f"MT5 init failed: {err}"}), 500

    tf = TIMEFRAME_MAP.get(tf_str)
    if tf is None:
        shutdown_mt5()
        return jsonify({"error": f"Timeframe inválido: {tf_str}"}), 400

    date_to   = datetime.now()
    date_from = date_to - timedelta(days=days)

    rates = mt5.copy_rates_range(symbol, tf, date_from, date_to)
    shutdown_mt5()

    if rates is None or len(rates) == 0:
        return jsonify({"error": f"Sem dados para {symbol} no período solicitado"}), 404

    df = pd.DataFrame(rates)
    df["time"] = pd.to_datetime(df["time"], unit="s")
    df = enrich_dataframe(df)

    # ── Candles individuais ──
    candles = []
    green_count = red_count = 0
    for _, row in df.iterrows():
        direction   = row["direction"]
        body_size   = abs(row["close"] - row["open"])
        total_range = row["high"] - row["low"]
        body_pct    = (body_size / total_range * 100) if total_range > 0 else 0

        # RSI label
        rsi_val = round(float(row["rsi"]), 1)
        if rsi_val >= 70:
            rsi_label = "Sobrecomprado"
        elif rsi_val <= 30:
            rsi_label = "Sobrevendido"
        else:
            rsi_label = "Neutro"

        # EMA trend
        ema_trend = "Alta" if row["close"] > row["ema21"] else "Baixa"

        candle = {
            "time":      row["time"].strftime("%Y-%m-%d %H:%M"),
            "date":      row["time"].strftime("%d/%m/%Y"),
            "hour":      row["hhmm"],
            "weekday":   DAYS_PT[row["weekday"]],
            "open":      round(float(row["open"]), 5),
            "high":      round(float(row["high"]), 5),
            "low":       round(float(row["low"]), 5),
            "close":     round(float(row["close"]), 5),
            "direction": direction,
            "body_size": round(body_size, 5),
            "body_pct":  round(body_pct, 1),
            "volume":    int(row["tick_volume"]),
            "vol_ratio": round(float(row["vol_ratio"]), 2),
            "rsi":       rsi_val,
            "rsi_label": rsi_label,
            "ema_trend": ema_trend,
        }
        candles.append(candle)
        if direction == "CALL":
            green_count += 1
        else:
            red_count += 1

    total     = green_count + red_count
    green_pct = round(green_count / total * 100, 1) if total > 0 else 0
    red_pct   = round(red_count   / total * 100, 1) if total > 0 else 0

    # ── Análise por hora ──
    hourly = []
    for h in range(24):
        subset = df[df["hour_only"] == h]
        if len(subset) == 0:
            continue
        calls   = int((subset["direction"] == "CALL").sum())
        puts    = int((subset["direction"] == "PUT").sum())
        total_h = calls + puts
        bias    = "CALL" if calls >= puts else "PUT"
        hist_sc = round(max(calls, puts) / total_h * 100, 1) if total_h > 0 else 50

        # Score composto para esse horário
        rsi_avg    = float(subset["rsi"].mean())
        vol_avg    = float(subset["vol_ratio"].mean())
        ema_align  = float((subset["close"] > subset["ema21"]).mean()) if bias == "CALL" else float((subset["close"] < subset["ema21"]).mean())

        comp = composite_score({
            "hist_score":    hist_sc,
            "rsi_avg":       rsi_avg,
            "ema_aligned":   ema_align,
            "vol_ratio_avg": vol_avg,
        }, bias)

        hourly.append({
            "hour":         f"{h:02d}:00",
            "calls":        calls,
            "puts":         puts,
            "total":        total_h,
            "call_pct":     round(calls / total_h * 100, 1) if total_h > 0 else 0,
            "put_pct":      round(puts  / total_h * 100, 1) if total_h > 0 else 0,
            "bias":         bias,
            "hist_score":   hist_sc,
            "rsi_avg":      round(rsi_avg, 1),
            "vol_avg":      round(vol_avg, 2),
            "ema_aligned":  round(ema_align * 100, 1),
            "comp_score":   comp,
        })

    # ── Análise por dia da semana ──
    weekday_stats = []
    for wd in range(7):
        subset = df[df["weekday"] == wd]
        if len(subset) == 0:
            continue
        calls   = int((subset["direction"] == "CALL").sum())
        puts    = int((subset["direction"] == "PUT").sum())
        total_w = calls + puts
        bias    = "CALL" if calls >= puts else "PUT"
        hist_sc = round(max(calls, puts) / total_w * 100, 1) if total_w > 0 else 50

        rsi_avg   = float(subset["rsi"].mean())
        vol_avg   = float(subset["vol_ratio"].mean())
        ema_align = float((subset["close"] > subset["ema21"]).mean()) if bias == "CALL" else float((subset["close"] < subset["ema21"]).mean())

        comp = composite_score({
            "hist_score":    hist_sc,
            "rsi_avg":       rsi_avg,
            "ema_aligned":   ema_align,
            "vol_ratio_avg": vol_avg,
        }, bias)

        # Cruzamento hora × dia (top 3 horários de cada dia)
        hour_day = []
        for h in range(24):
            s2 = subset[subset["hour_only"] == h]
            if len(s2) < 2:
                continue
            c2 = int((s2["direction"] == "CALL").sum())
            p2 = int((s2["direction"] == "PUT").sum())
            t2 = c2 + p2
            b2 = "CALL" if c2 >= p2 else "PUT"
            sc2 = round(max(c2, p2) / t2 * 100, 1)
            hour_day.append({"hour": f"{h:02d}:00", "bias": b2, "score": sc2, "total": t2})
        hour_day.sort(key=lambda x: -x["score"])

        weekday_stats.append({
            "weekday":      wd,
            "name":         DAYS_PT[wd],
            "calls":        calls,
            "puts":         puts,
            "total":        total_w,
            "call_pct":     round(calls / total_w * 100, 1) if total_w > 0 else 0,
            "put_pct":      round(puts  / total_w * 100, 1) if total_w > 0 else 0,
            "bias":         bias,
            "hist_score":   hist_sc,
            "rsi_avg":      round(rsi_avg, 1),
            "vol_avg":      round(vol_avg, 2),
            "comp_score":   comp,
            "top_hours":    hour_day[:5],
        })

    # ── Sequências consecutivas ──
    max_green_seq = max_red_seq = cur_green = cur_red = 0
    for c in candles:
        if c["direction"] == "CALL":
            cur_green += 1; cur_red = 0
            max_green_seq = max(max_green_seq, cur_green)
        else:
            cur_red += 1; cur_green = 0
            max_red_seq = max(max_red_seq, cur_red)

    return jsonify({
        "symbol":         symbol,
        "timeframe":      tf_str,
        "days":           days,
        "date_from":      date_from.strftime("%d/%m/%Y %H:%M"),
        "date_to":        date_to.strftime("%d/%m/%Y %H:%M"),
        "total_candles":  total,
        "green_count":    green_count,
        "red_count":      red_count,
        "green_pct":      green_pct,
        "red_pct":        red_pct,
        "max_green_seq":  max_green_seq,
        "max_red_seq":    max_red_seq,
        "hourly_stats":   hourly,
        "weekday_stats":  weekday_stats,
        "candles":        candles,
    })

@app.route("/api/shutdown", methods=["POST"])
def shutdown():
    import threading
    def stop():
        import time, os, signal
        time.sleep(0.5)
        os.kill(os.getpid(), signal.SIGTERM)
    threading.Thread(target=stop, daemon=True).start()
    return jsonify({"ok": True})

@app.route("/api/filter-signals", methods=["POST"])
def filter_signals():
    data      = request.json
    raw_list  = data.get("signals", "")
    days      = int(data.get("days", 30))
    min_score = float(data.get("min_score", 60))

    parsed_signals = []
    for line in raw_list.strip().splitlines():
        line = line.strip()
        if not line:
            continue
        parts = [p.strip() for p in line.split(",")]
        if len(parts) != 4:
            continue
        hour_str, symbol, direction, tf_str = parts
        direction = direction.upper()
        tf_str    = tf_str.upper()
        if direction not in ("CALL", "PUT"):
            continue
        if tf_str not in TIMEFRAME_MAP:
            continue
        parsed_signals.append({
            "hour": hour_str, "symbol": symbol.upper(),
            "direction": direction, "timeframe": tf_str,
        })

    if not parsed_signals:
        return jsonify({"error": "Nenhum sinal válido encontrado na lista."}), 400

    ok, err = init_mt5()
    if not ok:
        return jsonify({"error": f"MT5 init failed: {err}"}), 500

    date_to   = datetime.now()
    date_from = date_to - timedelta(days=days)

    combos = {}
    for s in parsed_signals:
        key = (s["symbol"], s["timeframe"])
        combos.setdefault(key, []).append(s)

    results = []

    for (symbol, tf_str), signals in combos.items():
        tf    = TIMEFRAME_MAP[tf_str]
        rates = mt5.copy_rates_range(symbol, tf, date_from, date_to)

        if rates is None or len(rates) == 0:
            for s in signals:
                results.append({**s, "error": "Sem dados históricos"})
            continue

        df = pd.DataFrame(rates)
        df["time"] = pd.to_datetime(df["time"], unit="s")
        df = enrich_dataframe(df)

        for s in signals:
            target_hour = s["hour"]
            target_dir  = s["direction"]
            subset      = df[df["hhmm"] == target_hour]
            total_h     = len(subset)

            if total_h == 0:
                results.append({**s, "total": 0, "hits": 0, "score": 0.0,
                                 "comp_score": 0.0, "status": "SEM_DADOS",
                                 "error": f"Nenhuma vela em {target_hour}"})
                continue

            hits      = int((subset["direction"] == target_dir).sum())
            hist_sc   = round(hits / total_h * 100, 1)
            rsi_avg   = float(subset["rsi"].mean())
            vol_avg   = float(subset["vol_ratio"].mean())
            ema_align = float((subset["close"] > subset["ema21"]).mean()) if target_dir == "CALL" else float((subset["close"] < subset["ema21"]).mean())

            comp = composite_score({
                "hist_score":    hist_sc,
                "rsi_avg":       rsi_avg,
                "ema_aligned":   ema_align,
                "vol_ratio_avg": vol_avg,
            }, target_dir)

            # Breakdown por dia da semana para esse horário
            weekday_breakdown = []
            for wd in range(7):
                sw = subset[subset["weekday"] == wd]
                if len(sw) == 0:
                    continue
                h_wd = int((sw["direction"] == target_dir).sum())
                sc_wd = round(h_wd / len(sw) * 100, 1)
                weekday_breakdown.append({
                    "name": DAYS_PT[wd], "hits": h_wd,
                    "total": len(sw), "score": sc_wd,
                })

            if comp >= 75:
                rating = "FORTE"
            elif comp >= 60:
                rating = "BOM"
            elif comp >= 50:
                rating = "NEUTRO"
            else:
                rating = "FRACO"

            results.append({
                "hour":               target_hour,
                "symbol":             symbol,
                "direction":          target_dir,
                "timeframe":          tf_str,
                "total":              total_h,
                "hits":               hits,
                "misses":             total_h - hits,
                "hist_score":         hist_sc,
                "rsi_avg":            round(rsi_avg, 1),
                "vol_avg":            round(vol_avg, 2),
                "ema_aligned_pct":    round(ema_align * 100, 1),
                "comp_score":         comp,
                "score":              comp,       # alias para compatibilidade UI
                "rating":             rating,
                "approved":           comp >= min_score,
                "weekday_breakdown":  weekday_breakdown,
            })

    shutdown_mt5()

    results.sort(key=lambda x: (-int(x.get("approved", False)), -x.get("comp_score", 0)))

    approved = [r for r in results if r.get("approved")]
    rejected = [r for r in results if not r.get("approved") and "error" not in r]
    no_data  = [r for r in results if "error" in r]

    return jsonify({
        "days": days, "min_score": min_score,
        "total_in": len(parsed_signals),
        "approved": approved, "rejected": rejected, "no_data": no_data,
    })


if __name__ == "__main__":
    import threading, webbrowser, sys, os

    PORT      = 5000
    is_frozen = getattr(sys, 'frozen', False)

    if is_frozen:
        app.template_folder = os.path.join(sys._MEIPASS, 'templates')

    def open_browser():
        import time
        time.sleep(1.2)
        webbrowser.open(f"http://localhost:{PORT}")

    def run_tray():
        try:
            import pystray
            from PIL import Image, ImageDraw
            img  = Image.new("RGB", (64, 64), color="#050a0e")
            draw = ImageDraw.Draw(img)
            draw.ellipse([8, 8, 56, 56], fill="#00ffe0")
            draw.rectangle([28, 20, 36, 44], fill="#050a0e")
            draw.rectangle([20, 36, 44, 44], fill="#050a0e")
            def on_open(icon, item): webbrowser.open(f"http://localhost:{PORT}")
            def on_quit(icon, item):
                icon.stop()
                import signal
                os.kill(os.getpid(), signal.SIGTERM)
            menu = pystray.Menu(
                pystray.MenuItem("Abrir no navegador", on_open, default=True),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("Encerrar", on_quit),
            )
            pystray.Icon("MT5 Signal Analyzer", img, "MT5 Signal Analyzer", menu).run()
        except Exception:
            pass

    threading.Thread(target=open_browser, daemon=True).start()
    threading.Thread(target=run_tray,    daemon=True).start()
    app.run(host="127.0.0.1", port=PORT, debug=False, use_reloader=False)
